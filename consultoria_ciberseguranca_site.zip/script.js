
// Função para aumentar o tamanho do texto
document.getElementById('aumentarTexto').addEventListener('click', () => {
    document.body.style.fontSize = '1.2rem';
});
